cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c **** Definitions for preprocessor directives
c      Ioannis Nompelis <nompelis@aem.umn.edu> Created:       20130613
c      Ioannis Nompelis <nompelis@umn.edu>     Last modified: 20190104
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

c
c *** remove the "NO_" from the definition below to use custom particle
c *** structures. Be careful. No particle restarts can be done.
c
#define NO_CUSTOM_PTCL_SAVIO

#ifdef CUSTOM_PTCL
#warning "Custom particle structures enabled"
#endif


#ifdef CUSTOM_PTCL_SAVIO
#warning "Custom particle structures for Savio enabled"
#endif

c
c *** revert to writing arrays of atomic types instead of structs in HDF5 files
c *** WARNING: This affects the post-processor!
c
#define _NO_LEVELTWO_STRUCT_
#ifdef  _NO_LEVELTWO_STRUCT_
#warning "Using arrays of atomic types for cell two datasets"
#endif

c
c *** revert to writing arrays of atomic types instead of structs in HDF5 files
c *** WARNING: This affects the post-processor!
c
#define _NO_LEVELTHREE_STRUCT_
#ifdef  _NO_LEVELTHREE_STRUCT_
#warning "Using arrays of atomic types for cell three datasets"
#endif

c
c *** revert to writing arrays of atomic types instead of structs in HDF5 files
c *** WARNING: This affects the post-processor!
c
#define _NO_CELLDATA_STRUCT_
#ifdef  _NO_CELLDATA_STRUCT_
#warning "Using arrays of atomic types for celldata datasets"
#endif

c
c *** revert to writing arrays of atomic types instead of structs in HDF5 files
c *** WARNING: This affects the post-processor!
c
#define _NO_PARTICLE_STRUCT_
#ifdef  _NO_PARTICLE_STRUCT_
#warning "Using arrays of atomic types for particle datasets"
#endif

